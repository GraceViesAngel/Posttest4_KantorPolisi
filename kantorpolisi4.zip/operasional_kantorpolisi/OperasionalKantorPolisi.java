package operasional_kantorpolisi;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import data_kantorpolisi.Kasus;
import data_kantorpolisi.JadwalPatroli;
import data_kantorpolisi.Polisi;
import data_kantorpolisi.StaffSipil;

public class OperasionalKantorPolisi {

    private final List<Polisi> listPolisi = new ArrayList<>();
    private final List<StaffSipil> listStaff = new ArrayList<>();
    private final List<JadwalPatroli> listJadwal = new ArrayList<>();
    private final List<Kasus> listKasus = new ArrayList<>();

    private int seqJadwal = 1;
    private int seqKasus = 1;

    // ======== AKSES LIST (dipakai menu) ========
    public List<Polisi> semuaPolisi() { return listPolisi; }
    public List<StaffSipil> semuaStaff() { return listStaff; }
    public List<JadwalPatroli> semuaJadwal() { return listJadwal; }
    public List<Kasus> semuaKasus() { return listKasus; }

    // ======== POLISI ========
    public void tambahPolisi(Polisi p) { listPolisi.add(p); } // versi lama (dipakai menu)
    // Overloading (syarat tugas) – tidak mengubah menu/output
    public void tambahPolisi(String nrp, String nama, String pangkat, String status) {
        tambahPolisi(new Polisi(nrp, nama, pangkat, status));
    }

    // cari (untuk tampilan hasil pencarian – mengembalikan LIST)
    public List<Polisi> cariPolisi(String keyword) {
        if (keyword == null) keyword = "";
        final String k = keyword.toLowerCase();
        return listPolisi.stream()
            .filter(p ->
                p.getNrp().toLowerCase().contains(k) ||
                p.getNama().toLowerCase().contains(k) ||
                p.getPangkat().toLowerCase().contains(k) ||
                p.getStatus().toLowerCase().contains(k)
            ).collect(Collectors.toList());
    }

    // find satu objek by NRP (dipakai menu di beberapa tempat)
    public Polisi findPolisi(String nrp) {
        for (Polisi p : listPolisi) if (p.getNrp().equals(nrp)) return p;
        return null;
    }

    public boolean ubahPolisi(String nrp, String nama, String pangkat, String status) {
        Polisi p = findPolisi(nrp);
        if (p == null) return false;
        if (nama != null) p.setNama(nama);
        if (pangkat != null) p.setPangkat(pangkat);
        if (status != null) p.setStatus(status);
        return true;
    }

    public boolean hapusPolisi(String nrp) {
        return listPolisi.removeIf(p -> p.getNrp().equals(nrp));
    }

    // ======== STAFF ========
    public void tambahStaff(StaffSipil s) { listStaff.add(s); }

    // cari (LIST) untuk tampilan hasil pencarian
    public List<StaffSipil> cariStaff(String keyword) {
        if (keyword == null) keyword = "";
        final String k = keyword.toLowerCase();
        return listStaff.stream()
            .filter(s ->
                s.getId().toLowerCase().contains(k) ||
                s.getNama().toLowerCase().contains(k) ||
                s.getBagian().toLowerCase().contains(k) ||
                s.getStatus().toLowerCase().contains(k)
            ).collect(Collectors.toList());
    }

    // find satu objek by ID
    public StaffSipil findStaff(String id) {
        for (StaffSipil s : listStaff) if (s.getId().equals(id)) return s;
        return null;
    }

    public boolean ubahStaff(String id, String nama, String bagian, String status) {
        StaffSipil s = findStaff(id);
        if (s == null) return false;
        if (nama != null) s.setNama(nama);
        if (bagian != null) s.setBagian(bagian);
        if (status != null) s.setStatus(status);
        return true;
    }

    public boolean hapusStaff(String id) {
        return listStaff.removeIf(s -> s.getId().equals(id));
    }

    // ======== JADWAL PATROLI ========
    public String tambahJadwal(String tanggal, String area, String penanggungJawabNrp) {
        String id = "J" + (seqJadwal++);
        listJadwal.add(new JadwalPatroli(id, tanggal, area, penanggungJawabNrp, "Dijadwalkan"));
        return id;
    }

    public boolean ubahJadwalStatus(String id, String statusBaru) { // dipakai dalam if(...)
        for (JadwalPatroli j : listJadwal) {
            if (j.getId().equals(id)) {
                j.setStatus(statusBaru);
                return true;
            }
        }
        return false;
    }

    public boolean ubahJadwalTanggal(String id, String tanggalBaru) {
        for (JadwalPatroli j : listJadwal) {
            if (j.getId().equals(id)) {
                j.setTanggal(tanggalBaru);
                return true;
            }
        }
        return false;
    }

    public boolean ubahJadwalArea(String id, String areaBaru) {
        for (JadwalPatroli j : listJadwal) {
            if (j.getId().equals(id)) {
                j.setArea(areaBaru);
                return true;
            }
        }
        return false;
    }

    public List<JadwalPatroli> filterJadwalArea(String area) {
        if (area == null) area = "";
        final String a = area.toLowerCase();
        return listJadwal.stream()
            .filter(j -> j.getArea().toLowerCase().contains(a))
            .collect(Collectors.toList());
    }

    public List<JadwalPatroli> filterJadwalStatus(String status) {
        if (status == null) status = "";
        final String s = status.toLowerCase();
        return listJadwal.stream()
            .filter(j -> j.getStatus().toLowerCase().contains(s))
            .collect(Collectors.toList());
    }

    public boolean hapusJadwal(String id) {
        return listJadwal.removeIf(j -> j.getId().equals(id));
    }

    // ======== KASUS ========
    public String tambahKasus(String judul, String penyidikNrp) {
        String id = "K" + (seqKasus++);
        listKasus.add(new Kasus(id, judul, penyidikNrp, "Terbuka"));
        return id;
    }

    public boolean ubahStatusKasus(String idKasus, String statusBaru) { // dipakai dalam if(...)
        for (Kasus k : listKasus) {
            if (k.getId().equals(idKasus)) {
                k.setStatus(statusBaru);
                return true;
            }
        }
        return false;
    }

    public List<Kasus> kasusByStatus(String status) {
        if (status == null) status = "";
        final String s = status.toLowerCase();
        return listKasus.stream()
            .filter(k -> k.getStatus().toLowerCase().equals(s))
            .collect(Collectors.toList());
    }

    public boolean hapusKasus(String idKasus) {
        return listKasus.removeIf(k -> k.getId().equals(idKasus));
    }

    // ==================== SEED (pakai data kamu) ====================
    public void seed() {
        tambahPolisi(new Polisi("101","Budi Hartono","Aiptu","Aktif"));
        tambahPolisi(new Polisi("102","Sari Wulandari","Kapolsek","Aktif"));
        tambahPolisi(new Polisi("103","Andi Pratama","Ipda","Cuti"));
        tambahPolisi(new Polisi("104","Rina Lestari","Aipda","Aktif"));
        tambahPolisi(new Polisi("105","Galuh Thalita","Kompol","Aktif"));
        tambahPolisi(new Polisi("106","Dhany Indra","Jendral","Aktif"));
        tambahPolisi(new Polisi("107","Kevin Immanuel","Brimob","Aktif"));

        tambahStaff(new StaffSipil("201","Rani Puspita","Administrasi","Aktif"));
        tambahStaff(new StaffSipil("202","Gilang P","Keuangan","Aktif"));
        tambahStaff(new StaffSipil("203","Sinta Lestari","Umum","Cuti"));

        tambahJadwal("09-09-2025","Pasar Raya","106");
        tambahJadwal("10-09-2025","Jl. Sudirman","103");
        String j3 = tambahJadwal("11-09-2025","Terminal Kota","105");
        ubahJadwalStatus(j3, "Telah Selesai");

        String k1 = tambahKasus("Pencurian Motor di Pasar Raya","101");
        String k2 = tambahKasus("Penipuan Online","102"); ubahStatusKasus(k2,"Proses");
        String k3 = tambahKasus("Penganiayaan Ringan","103"); ubahStatusKasus(k3,"Ditutup");
    }
}
