package data_kantorpolisi;

public class StaffSipil extends Personel implements Pelaporan {
    private String bagian; // Administrasi/Keuangan/Umum
    private String status; // Aktif / Cuti

    public StaffSipil(String id, String nama, String bagian, String status) {
        super(id, nama);
        this.bagian = bagian;
        this.status = status;
    }

    public String getBagian() { return bagian; }
    public void   setBagian(String bagian) { this.bagian = bagian; }

    public String getStatus() { return status; }
    public void   setStatus(String status) { this.status = status; }

    // Overriding (dari Personel)
    @Override
    public String deskripsiTugas() {
        return "Mendukung operasional kantor (administrasi, arsip, keuangan)";
    }

    // Interface (nilai tambah)
    @Override
    public String buatLaporanSingkat() {
        return "Staff " + getNama() + " (" + getId() + ") - " + bagian + " - " + status;
    }

    @Override
    public String toString() {
        return getId() + " | " + getNama() + " | " + bagian + " | " + status;
    }
}
