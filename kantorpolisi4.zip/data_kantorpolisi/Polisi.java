package data_kantorpolisi;

public class Polisi extends Personel implements Pelaporan {
    private String pangkat;
    private String status; // Aktif / Cuti

    public Polisi(String nrp, String nama, String pangkat, String status) {
        super(nrp, nama);   // id = nrp (kompatibel dgn menu/output lama)
        this.pangkat = pangkat;
        this.status  = status;
    }

    // Alias yang dipakai di banyak tempat
    public String getNrp() { return getId(); }
    public void   setNrp(String nrp) { setId(nrp); }

    public String getPangkat() { return pangkat; }
    public void   setPangkat(String pangkat) { this.pangkat = pangkat; }

    public String getStatus() { return status; }
    public void   setStatus(String status) { this.status = status; }

    // Overriding (dari Personel)
    @Override
    public String deskripsiTugas() {
        return "Menjaga keamanan, patroli, penegakan hukum, dan pelayanan masyarakat";
    }

    // Interface (nilai tambah)
    @Override
    public String buatLaporanSingkat() {
        return "Polisi " + getNama() + " (" + getNrp() + ") - " + pangkat + " - " + status;
    }

    @Override
    public String toString() {
        return getNrp() + " | " + getNama() + " | " + pangkat + " | " + status;
    }
}
