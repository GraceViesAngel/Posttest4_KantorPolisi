package data_kantorpolisi;

public interface Pelaporan {
    String buatLaporanSingkat();
}
