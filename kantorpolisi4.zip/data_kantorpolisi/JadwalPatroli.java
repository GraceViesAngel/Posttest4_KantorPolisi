package data_kantorpolisi;

public class JadwalPatroli {
    private String id;                 // J1, J2, ...
    private String tanggal;            // "09-09-2025"
    private String area;
    private String penanggungJawabNrp; // NRP Polisi penanggung jawab
    private String status;             // "Dijadwalkan", "Telah Selesai", "Dibatalkan"

    public JadwalPatroli(String id, String tanggal, String area, String penanggungJawabNrp, String status) {
        this.id = id;
        this.tanggal = tanggal;
        this.area = area;
        this.penanggungJawabNrp = penanggungJawabNrp;
        this.status = status;
    }

    public String getId() { return id; }

    public String getTanggal() { return tanggal; }
    public void setTanggal(String tanggal) { this.tanggal = tanggal; }

    public String getArea() { return area; }
    public void setArea(String area) { this.area = area; }

    public String getPenanggungJawabNrp() { return penanggungJawabNrp; }
    public void setPenanggungJawabNrp(String nrp) { this.penanggungJawabNrp = nrp; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // Alias agar cocok dengan AplikasiKantorPolisi.java
    public String getNrp() { return penanggungJawabNrp; }
    public void setNrp(String nrp) { this.penanggungJawabNrp = nrp; }
}
